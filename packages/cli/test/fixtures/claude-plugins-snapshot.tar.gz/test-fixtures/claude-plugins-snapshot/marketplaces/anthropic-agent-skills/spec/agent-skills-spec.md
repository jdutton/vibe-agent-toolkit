# Agent Skills Spec

The spec is now located at <https://agentskills.io/specification>
